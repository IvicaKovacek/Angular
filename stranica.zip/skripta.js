$(document).ready(function(){
 
    $('#okidac').on('click',function(){
        $('.kutija').slideToggle();
    });
 
    $('.navigacija li').hover(function(){
        $(this).find('ul').slideToggle();
    });   
	
	$('.tabs li').on('click', function(){
        $('.tabs li.active').removeClass('active');
        $(this).addClass('active');
 
        var kojiPanel = $(this).attr('rel');
 
        $('.panel.active').hide(panel);
 
        function panel() {
            $(this).removeClass('active');
            
            $('#'+kojiPanel).show(function(){
                $(this).addClass('active');
            });
        }
    });
	
});

