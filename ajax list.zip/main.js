var btn1 = document.getElementById('btn');
var mainUl1 = document.getElementById('mainUl');
var text ="";

btn1.addEventListener('click', function () {
	var xmlXttp = new XMLHttpRequest();
	xmlXttp.onreadystatechange = function () {
		if (xmlXttp.readyState == 4 && xmlXttp.status == 200) {
			data(xmlXttp);
		}
	}
	xmlXttp.open('GET','http://mysafeinfo.com/api/data?list=presidents&format=json',true);
	xmlXttp.send();
});

function data(dataJson) {
	var allData = JSON.parse(dataJson.responseText);
		allData.forEach(function (e,i) {
			text += "<li>"+e.president+"</li>"
			text += "<li>"+e.nm+"</li>"
			text += "<li>"+e.pp+"</li>"
			text += "<li>"+e.tm+"</li>"
			text += "<p></p>"
		})
		mainUl1.innerHTML = text;
		
}