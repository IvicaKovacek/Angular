import pygame
from random import shuffle

X_RES = 800
Y_RES = 600
BLACK = (0, 0, 0)
FPS = 15

class Game(object):
    # Note: The number of pairs needs to be odd.
    def __init__(self, n_pairs):
        self.max_pairs = n_pairs
        self.kraj_igre = False
        self.winner_displayed = False

    def setup_cards(self):
        self.cards = []
        for card in range(1, self.max_pairs +1):
            self.cards.append(card)
            self.cards.append(card)
        shuffle(self.cards)
        self.eliminated_cards = []
        self.selected_cards = []

    def start(self):
        self.players = [Player("Player 1"), Player("Player 2")]
        self.turn = 0
        self.current_player = 0
        self.time_of_last_click = None
        self.setup_cards()
        print("Go, " + self.players[self.current_player].name + "!")

    def select_card(self, selected_card_ID):
        if selected_card_ID not in self.selected_cards and \
        selected_card_ID not in self.eliminated_cards and \
        len(self.selected_cards) < 2:
            self.selected_cards.append(selected_card_ID)
            self.time_of_last_click = pygame.time.get_ticks()

    def next_action(self):
        if len(self.selected_cards) == 2 and \
           self.time_of_last_click + 1000 < pygame.time.get_ticks():
            if self.cards[self.selected_cards[0]] == \
               self.cards[self.selected_cards[1]]:
                print("Correct!")
                self.players[self.current_player].score += 1
                self.print_score()
                print("Go again, " + self.players[self.current_player].name + "!")
                # delete the cards
                self.eliminated_cards += self.selected_cards
                if len(self.cards) == len(self.eliminated_cards):
                    game.kraj_igre = True
            else:
                print("Wrong!")
                self.print_score()
                self.current_player = 1 - self.current_player
                print("Go, " + self.players[self.current_player].name + "!")
            self.selected_cards = []

    def print_score(self):
        print("-----Score-----")
        print("Player 1: " + str(self.players[0].score))
        print("Player 2: " + str(self.players[1].score))
        print("--" * 10)

    def get_winner(self):
        return self.players[0] if self.players[0].score > \
               self.players[1].score else self.players[1]

class Player(object):
    def __init__(self, name):
        self.score = 0
        self.name = name

class CardSprite(pygame.sprite.Sprite):
    def __init__(self, index):
        super(CardSprite, self).__init__()
        self.ID = index
        self.karta = game.cards[self.ID]
        self.image_fg = pygame.image.load("card" + str(self.karta) + ".png")
        self.image_bg = pygame.image.load("back.png")
        self.image = self.image_bg
        self.rect = self.image.get_rect()
        self.rect.x = 10 + self.ID % 3 * 150
        self.rect.y = 100 + self.ID / 3 * 200

def detect_clicked_card(position):
    clicked = [card for card in cards if card.rect.collidepoint(position)]
    return clicked[0] if len(clicked) == 1 else None

def get_drawable_cards(cards, game, sprite_group):
    sprite_group.empty()
    sprite_group.add([card for card in cards if card.ID not in
        game.eliminated_cards])

def flip_card_sprites(cards, game):
    for card in cards:
        if card.ID in game.selected_cards:
            card.image = card.image_fg
        else:
            card.image = card.image_bg


screen = pygame.display.set_mode([X_RES, Y_RES])
screen.fill(BLACK)

clock = pygame.time.Clock()

cards = pygame.sprite.Group()
to_draw = pygame.sprite.Group()

game = Game(3)
game.start()

for unique_ID in range(game.max_pairs * 2):
    card = CardSprite(unique_ID)
    cards.add(card)

while True:
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT or event.type == pygame.KEYDOWN and \
        event.key == pygame.K_ESCAPE:
            exit(0)
        elif event.type == pygame.MOUSEBUTTONUP:
            clicked_card = detect_clicked_card(pygame.mouse.get_pos())
            if clicked_card:
                game.select_card(clicked_card.ID)

    game.next_action()

    if game.kraj_igre and not game.winner_displayed:
        game.winner_displayed = True
        winner = game.get_winner()
        print("Winner is: " + winner.name + " with " + str(winner.score) + " points.")

    if game.kraj_igre and game.time_of_last_click + 4000 < pygame.time.get_ticks():
        break

    get_drawable_cards(cards, game, to_draw)
    flip_card_sprites(to_draw, game)
    to_draw.draw(screen)
    pygame.display.flip()
    clock.tick(FPS)
	
pygame.quit()
